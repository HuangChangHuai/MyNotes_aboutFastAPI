# [视频教学地址](https://space.bilibili.com/396891097)
## 中文学习教程
- 1、本教程每一个案例都可以独立跑，前提是安装好依赖包。
- 2、本教程并未按照官方教程顺序，而是按照实际使用顺序编排。

# [Video Teaching Address](https://space.bilibili.com/396891097)
## FastAPI Learning Example
- 1.Each case in this tutorial can run independently, provided that the dependency package is installed.
- 2.This tutorial is not in the order of official tutorials, but in the order of actual use.

